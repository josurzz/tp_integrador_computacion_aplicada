#!/bin/bash

if [ "$1" == "-help" ]; then
    echo "-----------------------------------------------------------------"
    echo "   Ayuda para el script de backup"
    echo "-----------------------------------------------------------------"
    echo "Uso correcto: ./backup_full.sh [ruta de origen para backupear] [destino donde se guardara el .tar.gz]"
    echo ""
    echo "Ejemplo: ./backup_full.sh /var/log /backup_dir"
    echo "-----------------------------------------------------------------"
    exit 0
fi

ORIGEN=$1 #asigno el primer parametro que me llegue como origen
DESTINO=$2 ##asigno el segundo parametro que me llegue como destino

if [ ! -d "$ORIGEN" ]; then #me fijo si es un directorio, si es valido, lo niego para que no ingrese al if
    echo "ERROR: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi


if [ ! -d "$DESTINO" ]; then #me fijo si es un directorio, si es valido, lo niego para que no ingrese al if
    echo "ERROR: El directorio de destino '$DESTINO' no existe o no está disponible."
    exit 1
fi


FECHA=$(date +"%Y%m%d")  #formateo la fecha para que quede como YYYYMMDD
#https://extassisnetwork.com/tutoriales/comando-fecha-linux/
#La salida de date puede formatearse con una secuencia de caracteres de formato precedidos por un signo +. Los controles comienzan con el % símbolo y se sustituyen por sus valores.
#date +"Year: %Y, Month: %m, Day: %d"

NOMBRE_CARPETA_ORIGEN=$(basename "$ORIGEN") #agarra el nombre de la ultima carpeta de la ruta que se puso
ARCHIVO_TAR="${DESTINO}/${NOMBRE_CARPETA_ORIGEN}_bkp_${FECHA}.tar.gz" # setea el nombre de donde se guarda y como se llamara el archivo final

tar -czvf "$ARCHIVO_TAR" "$ORIGEN" #comprimimos


#https://www.hostinger.com/ar/tutoriales/como-usar-comando-tar-linux
#c – crear un nuevo archivo .tar
#v – muestra una descripción detallada del progreso de la compresión
#f – nombre del archivo
#z - hace la compresion gzip
