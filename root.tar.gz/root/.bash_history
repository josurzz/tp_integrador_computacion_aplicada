history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cd Material_Adicional_TPVMCA
ls
cat plave_privada.txt
cat clave_privada.txt
exit
clear
exit
cd
ls
ls Material_Adicional_TPVMCA/clave_privada.txt
cat Material_Adicional_TPVMCA/clave_privada.txt
cd .ssh
ls
cd
cd /etc/ssh
ls
nano sshd_config.d
nano sshd_config
systemctl restart ssh
exit
clear
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking  
ip a
df -h
cd /opt
ls
ls
mkdir scripts
cd scripts
nano backup_full.sh
date | figlet
date
date +"%Y%m%d"
basename /var/log
basename /var
basename
basename /var/log/fesfad
dirname /var/log
nano backup_full.sh 
./backup_full.sh -help
nano backup_full.sh 
clear
ls -l
chmod +x /opt/scripts/backup_full.sh 
ls -l
./backup_full.sh -help
nano backup_full.sh 
./backup_full.sh -help
nano backup_full.sh 
ip a
reboot now
clear
lslbk
lsblk
df -h
